Ahmed stickers - Arab Para Taekwondo Basics Championship 2026
21 WhatsApp stickers (WebP 512x512, transparent, each under 100 KB) + tray.png (96x96).
How to add to WhatsApp (no coding):
1) Install a sticker-pack app such as "Sticker Maker" (Android / iPhone).
2) Create a new pack, add the 21 .webp files in order (Add sticker from gallery), set tray.png as the pack icon.
3) Press "Add to WhatsApp".
contents.json is the standard WhatsApp sticker-pack manifest (for developers / pack tools).
